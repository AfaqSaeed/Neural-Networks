import copy
class NeuralNetwork:
    
    def __init__(self,optimizer) -> None:
        self.optimizer = optimizer
        self.layers = []
        self.data_layer = None
        self.loss_layer = None
        self.loss = []
    def append_layer(self,layer):
        if layer.trainable:
            layer.optimizer = copy.deepcopy(self.optimizer)
        self.layers.append(layer)
            
    def forward(self):
        input_tensor,label_tensor=self.data_layer.next()
        self.label_tensor = label_tensor
        for i,layer in enumerate(self.layers):
            if i==0:
                output_tensor = layer.forward(input_tensor)
            else:
                output_tensor = layer.forward(output_tensor)
        self.prediction = output_tensor
        loss =self.loss_layer.forward(output_tensor,label_tensor) 
       
        return loss
    def backward(self):
    
        gradient = self.loss_layer.backward(self.label_tensor) 
       
        for i,layer in enumerate(reversed(self.layers)):
            
            gradient = layer.backward(gradient)
        
    def train(self,iterations):
        for iter in range(0,iterations):
            loss = self.forward()
            self.loss.append(loss)
            self.backward()
    def test(self,input_tensor):
            
        for i,layer in enumerate(self.layers):
            if i==0:
                output_tensor = layer.forward(input_tensor)
            else:
                output_tensor = layer.forward(output_tensor)
        
        return output_tensor