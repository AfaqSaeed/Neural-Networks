from Layers.Base import BaseLayer
import numpy as np 
class FullyConnected(BaseLayer):
    @property
    def optimizer(self):
        return self._optimizer
    @optimizer.setter
    def optimizer(self, optimizer):
        self._optimizer = optimizer
    

    def __init__(self,input_size, output_size) -> None:
        super().__init__()
        self.trainable=True
        self.input_size = input_size
        self.optimizer = None
        self.output_size = output_size
        self.weights = np.random.rand(input_size+1,output_size)
    
    def forward(self,input_tensor):
        ones = np.ones((input_tensor.shape[0],1))
        appended_tensor = np.hstack((input_tensor,ones))
        
        self.input_tensor = appended_tensor
        output_tensor = np.dot(appended_tensor,self.weights)

        return output_tensor

    def backward(self,error_tensor):
        gradient = np.dot(self.input_tensor.T,error_tensor)
        error_return =  np.dot(error_tensor,self.weights[:-1].T)
   
        if self.optimizer:
            self.weights = self.optimizer.calculate_update(self.weights,gradient)
        self.gradient_weights = gradient
        return error_return
